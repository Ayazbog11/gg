package com.experimental.star_map;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private int clicks = 0;
    private int level = 1;
    private int clicksPerClick = 1;
    private int clicksToNextLevel = 100;

    private TextView tvClicks, tvLevel;
    private Button btnClick, btnUpgrade1, btnUpgrade2, btnUpgrade3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvClicks = findViewById(R.id.tvClicks);
        tvLevel = findViewById(R.id.tvLevel);
        btnClick = findViewById(R.id.btnClick);
        btnUpgrade1 = findViewById(R.id.btnUpgrade1);
        btnUpgrade2 = findViewById(R.id.btnUpgrade2);
        btnUpgrade3 = findViewById(R.id.btnUpgrade3);

        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicks += clicksPerClick;
                tvClicks.setText("Clicks: " + clicks);
                checkLevelUp();
            }
        });

        btnUpgrade1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                upgradeClicks(1);
            }
        });

        btnUpgrade2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                upgradeClicks(2);
            }
        });

        btnUpgrade3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                upgradeClicks(3);
            }
        });
    }

    private void checkLevelUp() {
        if (clicks >= clicksToNextLevel) {
            level++;
            clicksToNextLevel = 100 * level * level;
            tvLevel.setText("Level: " + level);
            tvClicks.setText("Clicks: " + clicks);
        }
    }

    private void upgradeClicks(int upgradeType) {
        int upgradeCost = 50 * level;
        if (clicks >= upgradeCost) {
            clicks -= upgradeCost;
            clicksPerClick += upgradeType;
            tvClicks.setText("Clicks: " + clicks);
        }
    }
}
